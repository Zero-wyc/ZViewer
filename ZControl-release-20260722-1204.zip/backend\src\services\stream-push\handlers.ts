import { Server as SocketIOServer } from 'socket.io';
import { AppDataSource } from '../../data-source';
import { Room, type ShareMethod } from '../../entities/Room';
import { roomPermissionService } from '../../modules/room/room-permission.service';

// 注册推流模式相关 socket 事件
// 内部注册 io.on('connection', ...)，所有事件均在该处理器内注册
export function registerStreamPushHandlers(io: SocketIOServer): void {
  io.on('connection', (socket) => {
    // --- 房主切换投屏子模式（webrtc <-> stream-push） ---
    socket.on(
      'update-share-method',
      async (
        payload: { roomId: string; shareMethod: ShareMethod },
        callback?: (response: {
          success: boolean;
          message?: string;
          data?: { shareMethod?: ShareMethod };
        }) => void,
      ) => {
        try {
          // 通过统一权限服务校验房主身份
          if (!(await roomPermissionService.isRoomHost(socket, payload.roomId))) {
            return callback?.({ success: false, message: '无权限：仅房主可切换子模式' });
          }

          const roomRepo = AppDataSource.getRepository(Room);
          const room = await roomRepo.findOneBy({ roomId: payload.roomId });
          if (!room) {
            return callback?.({ success: false, message: '房间不存在' });
          }
          if (room.mode !== 'screen-share') {
            return callback?.({
              success: false,
              message: '仅投屏模式支持子模式切换',
            });
          }

          room.shareMethod = payload.shareMethod;
          await roomRepo.save(room);

          console.log(
            `[update-share-method] room=${payload.roomId} shareMethod=${payload.shareMethod}`,
          );

          io.to(payload.roomId).emit('share-method-changed', {
            roomId: payload.roomId,
            shareMethod: payload.shareMethod,
          });

          // AckResponse 标准格式：业务数据放在 data 字段内
          callback?.({
            success: true,
            data: { shareMethod: payload.shareMethod },
          });
        } catch (err) {
          console.error('update-share-method error:', err);
          callback?.({ success: false, message: '切换子模式失败' });
        }
      },
    );
  });
}
