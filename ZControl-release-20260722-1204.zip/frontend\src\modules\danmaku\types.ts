/** 弹幕源类型（移除了 bilibili_bangumi） */
export type DanmakuSource = 'bilibili' | 'bahamut' | 'dandanplay'

/** 弹幕条目（统一格式，所有源共用） */
export interface DanmakuItem {
  id: string
  content: string
  time: number
  mode: number
  color: number
  size: number
}

/** 弹幕轨道 */
export interface DanmakuTrack {
  trackId: string
  label: string
  source: DanmakuSource
  items: DanmakuItem[]
  offset: number
}

/** 搜索结果 */
export interface DanmakuSearchResult {
  identifier: string
  title: string
  description?: string
  cover?: string
}

/** 集数信息 */
export interface DanmakuEpisode {
  id: string
  title: string
  episodeNumber: number
}

/** 弹幕源选项 */
export const DANMAKU_SOURCE_OPTIONS: Array<{ label: string; value: DanmakuSource }> = [
  { label: '哔哩哔哩', value: 'bilibili' },
  { label: '巴哈姆特', value: 'bahamut' },
  { label: '弹弹play', value: 'dandanplay' },
]
