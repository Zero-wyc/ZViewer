import {
  DanmakuSourceProvider,
  DanmakuSearchResult,
  DanmakuEpisode,
  DanmakuItem,
} from '../types';

const DEFAULT_USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

/** fetch 请求统一超时时间（毫秒）。 */
const FETCH_TIMEOUT_MS = 10_000;

interface BahamutSearchResult {
  sn: string;
  title: string;
  cover?: string;
}

interface BahamutEpisodeInfo {
  sn: string;
  label: string;
}

/** 解码常见的 HTML 实体，避免标题中出现 &amp; 等转义字符。 */
function decodeHtmlEntities(input: string): string {
  return input
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

/**
 * 创建一个带超时的 AbortController，超时后会自动 abort。
 * 返回 controller 与清理函数，调用方需在请求结束后调用 clear 清理定时器。
 */
function createTimeoutSignal(timeoutMs: number = FETCH_TIMEOUT_MS): {
  signal: AbortSignal;
  clear: () => void;
} {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return {
    signal: controller.signal,
    clear: () => clearTimeout(timer),
  };
}

/** 将可能是网络错误/超时的异常转换为带语义的错误消息。 */
function wrapNetworkError(stage: string, url: string, err: unknown): Error {
  if (err instanceof Error) {
    // AbortError 来自超时
    if (err.name === 'AbortError') {
      return new Error(`巴哈姆特${stage}超时（${FETCH_TIMEOUT_MS / 1000}s）：${url}`);
    }
    // 其它 TypeError / 网络层错误
    return new Error(`巴哈姆特${stage}网络错误：${err.message}`);
  }
  return new Error(`巴哈姆特${stage}发生未知错误`);
}

/** 抓取指定 URL 的 HTML 文本，带超时与错误归一化。 */
async function fetchHtml(url: string): Promise<string> {
  const { signal, clear } = createTimeoutSignal();
  let res: Response;
  try {
    res = await fetch(url, {
      signal,
      headers: {
        'User-Agent': DEFAULT_USER_AGENT,
        Referer: 'https://ani.gamer.com.tw',
        Accept:
          'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8',
      },
    });
  } catch (err) {
    throw wrapNetworkError('请求页面', url, err);
  } finally {
    clear();
  }

  if (!res.ok) {
    throw new Error(`巴哈姆特请求失败 [HTTP ${res.status}]：${url}`);
  }

  try {
    return await res.text();
  } catch (err) {
    throw new Error(`巴哈姆特读取页面内容失败：${err instanceof Error ? err.message : String(err)}`);
  }
}

/**
 * 通过关键词搜索巴哈姆特番剧。
 * 解析 search.php 返回的 HTML，提取 theme-list-main 区块。
 * 搜索结果链接格式为 <a href='animeRef.php?sn=XXX' class='theme-list-main'>
 *（注意：巴哈姆特搜索页使用单引号属性），标题在 alt 属性或 theme-name 标签中。
 */
async function searchBahamutByKeyword(keyword: string): Promise<BahamutSearchResult[]> {
  const html = await fetchHtml(
    `https://ani.gamer.com.tw/search.php?keyword=${encodeURIComponent(keyword)}`,
  );

  const results: BahamutSearchResult[] = [];
  const seen = new Set<string>();

  // 按 theme-list-main 切分搜索结果块（属性用单引号）
  const blocks = html.split("class='theme-list-main'");
  for (let i = 1; i < blocks.length; i++) {
    const block = blocks[i];
    // 提取 sn（animeRef.php?sn=XXX）
    const snMatch = block.match(/animeRef\.php\?sn=(\d+)/);
    if (!snMatch) continue;
    const sn = snMatch[1];
    if (seen.has(sn)) continue;
    seen.add(sn);

    // 优先从 alt 属性提取标题，回退到 theme-name 标签
    const altMatch = block.match(/alt='([^']+)'/);
    const nameMatch = block.match(/class='theme-name'>([^<]+)</);
    const title = decodeHtmlEntities(
      (altMatch?.[1] || nameMatch?.[1] || `番剧 SN${sn}`).trim(),
    );

    // 提取封面图
    const coverMatch = block.match(/data-src='([^']+)'/);

    results.push({ sn, title, cover: coverMatch?.[1] });
  }

  return results.slice(0, 20);
}

/**
 * 通过番剧 sn（animeRef.php 的 sn）获取该番剧下的所有集数。
 * animeRef.php 页面包含剧集列表，格式为：
 * <a href="?sn=XXX" data-ani-video-sn="XXX">集数编号</a>
 */
async function getBahamutEpisodesBySn(sn: string): Promise<BahamutEpisodeInfo[]> {
  const html = await fetchHtml(`https://ani.gamer.com.tw/animeRef.php?sn=${sn}`);

  const episodes: BahamutEpisodeInfo[] = [];
  const seen = new Set<string>();

  // 匹配 data-ani-video-sn="XXX" 的链接，提取 sn 和显示文本（集数编号）
  const epRegex = /<a[^>]*data-ani-video-sn="(\d+)"[^>]*>([^<]+)<\/a>/g;
  let match: RegExpExecArray | null;
  while ((match = epRegex.exec(html)) !== null) {
    const epSn = match[1];
    if (seen.has(epSn)) continue;
    seen.add(epSn);
    const label = match[2].trim();
    episodes.push({ sn: epSn, label });
  }

  // 若未匹配到剧集列表，认为当前番剧只有一集，使用番剧自身的首个 animeVideo sn
  if (episodes.length === 0) {
    // 从 animeRef 页面提取 animeVideo.php?sn=XXX
    const videoSnMatch = html.match(/animeVideo\.php\?sn=(\d+)/);
    const videoSn = videoSnMatch ? videoSnMatch[1] : sn;
    episodes.push({ sn: videoSn, label: '1' });
  }

  return episodes;
}

/**
 * 将颜色值解析为统一的数字格式（0xRRGGBB）。
 * 兼容 #RRGGBB、#RGB、纯数字（十进制）等多种输入。
 */
function parseBahamutColor(color: unknown): number {
  if (typeof color === 'number' && Number.isFinite(color)) {
    return color;
  }
  if (typeof color === 'string') {
    const trimmed = color.trim().replace(/^#/, '');
    if (!trimmed) return 0xffffff;
    // #RGB 缩写形式扩展为 #RRGGBB
    const expanded = trimmed.length === 3
      ? trimmed.split('').map((c) => c + c).join('')
      : trimmed;
    const parsed = parseInt(expanded, 16);
    if (Number.isFinite(parsed)) return parsed;
    // 可能是十进制字符串
    const dec = parseInt(trimmed, 10);
    if (Number.isFinite(dec)) return dec;
  }
  return 0xffffff;
}

/**
 * 将巴哈姆特弹幕的 size 档位映射为实际像素字号。
 * 巴哈姆特返回的 size 为档位值（1=小, 2=中, 3=大），需转换为像素值。
 */
function mapBahamutSize(size: unknown): number {
  if (typeof size !== 'number' || !Number.isFinite(size)) return 25;
  switch (size) {
    case 1:
      return 20; // 小
    case 2:
      return 28; // 中
    case 3:
      return 36; // 大
    default:
      return 25;
  }
}

/** 调用巴哈姆特弹幕接口获取指定 sn 的弹幕列表。 */
async function getBahamutDanmaku(sn: string): Promise<DanmakuItem[]> {
  const url = 'https://ani.gamer.com.tw/ajax/danmuGet.php';
  const { signal, clear } = createTimeoutSignal();
  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      signal,
      headers: {
        'User-Agent': DEFAULT_USER_AGENT,
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        Referer: `https://ani.gamer.com.tw/animeVideo.php?sn=${sn}`,
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: new URLSearchParams({ sn }).toString(),
    });
  } catch (err) {
    throw wrapNetworkError('获取弹幕', url, err);
  } finally {
    clear();
  }

  if (!res.ok) {
    throw new Error(`巴哈姆特弹幕接口返回失败 [HTTP ${res.status}]`);
  }

  // 巴哈姆特弹幕接口直接返回数组（非 { data: [] } 包装）
  let json: Array<{
    text?: string;
    time?: number | string;
    color?: string | number;
    position?: number;
    sn?: number | string;
    size?: number;
  }>;
  try {
    json = await res.json();
  } catch (err) {
    throw new Error(`巴哈姆特弹幕接口响应解析失败：${err instanceof Error ? err.message : String(err)}`);
  }

  // 兼容数组或 { data: [] } 两种返回格式
  const list = Array.isArray(json)
    ? json
    : Array.isArray((json as unknown as { data?: unknown[] }).data)
      ? (json as unknown as { data: typeof json }).data
      : [];

  const items: DanmakuItem[] = [];
  for (const d of list) {
    if (typeof d.text !== 'string' || !d.text.trim()) continue;

    // 巴哈姆特弹幕 time 单位为毫秒，需除以 1000 转换为秒
    const timeNum = typeof d.time === 'number'
      ? d.time
      : parseFloat(String(d.time ?? '0'));
    const time = Number.isFinite(timeNum) ? timeNum / 1000 : 0;

    // position: 0=滚动, 1=顶部, 2=底部, 3=特殊
    // 与统一格式（0=滚动, 1=顶部, 2=底部）一致，3 及其它未知值回退为滚动
    const rawMode = typeof d.position === 'number' ? d.position : 0;
    const mode = rawMode === 1 || rawMode === 2 ? rawMode : 0;

    items.push({
      id: String(d.sn ?? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`),
      content: d.text,
      time,
      mode,
      color: parseBahamutColor(d.color),
      size: mapBahamutSize(d.size),
    });
  }

  return items;
}

export const bahamutDanmakuProvider: DanmakuSourceProvider = {
  name: '巴哈姆特动画疯',

  async search(keyword: string): Promise<DanmakuSearchResult[]> {
    const results = await searchBahamutByKeyword(keyword);
    return results.map((r) => ({
      id: r.sn,
      title: r.title,
      cover: r.cover,
      source: 'bahamut',
      extra: { sn: r.sn },
    }));
  },

  async getEpisodes(identifier: string): Promise<DanmakuEpisode[]> {
    const sn = identifier.replace(/\D/g, '');
    if (!sn) {
      throw new Error('无法解析巴哈姆特 SN');
    }

    const episodes = await getBahamutEpisodesBySn(sn);
    return episodes.map((ep, idx) => ({
      id: ep.sn,
      title: `第 ${ep.label} 集`,
      episodeNumber: idx + 1,
      playbackParams: { sn: ep.sn },
    }));
  },

  async getDanmaku(episode: DanmakuEpisode): Promise<DanmakuItem[]> {
    const sn = episode.playbackParams.sn;
    if (typeof sn !== 'string' || !sn) {
      throw new Error('缺少巴哈姆特 sn 参数');
    }
    return getBahamutDanmaku(sn);
  },
};
